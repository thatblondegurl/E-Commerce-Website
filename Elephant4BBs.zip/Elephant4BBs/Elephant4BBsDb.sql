-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 22, 2021 at 02:51 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `elephants4bbs1`
--
CREATE DATABASE IF NOT EXISTS `elephants4bbs1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `elephants4bbs1`;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `OID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ORDER_NO` varchar(45) NOT NULL DEFAULT '',
  `ORDER_DATE` date NOT NULL DEFAULT '0000-00-00',
  `UID` int(10) unsigned NOT NULL DEFAULT '0',
  `TOTAL_AMT` double(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`OID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE IF NOT EXISTS `order_details` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `OID` int(10) unsigned NOT NULL DEFAULT '0',
  `PID` int(10) unsigned NOT NULL DEFAULT '0',
  `PNAME` varchar(45) NOT NULL DEFAULT '',
  `PRICE` double(10,2) NOT NULL DEFAULT '0.00',
  `QTY` int(10) unsigned NOT NULL DEFAULT '0',
  `TOTAL` double(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `PID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PRODUCT` varchar(45) NOT NULL DEFAULT '',
  `PRICE` double(10,2) NOT NULL DEFAULT '0.00',
  `IMAGE` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION` text,
  PRIMARY KEY (`PID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `products`
--



INSERT INTO `products` (`PID`, `PRODUCT`, `PRICE`, `IMAGE`, `DESCRIPTION`) VALUES
(1, 'Anxiety Relief Teether', 17.00, '1.jpg', 'Sensory chew teether. safe chewing option for individuals with sensory needs, such as Autism, PDD, and ADHD.'),
(2, 'Elephant Massage Teether', 13.00, '2.jpg', 'Designed to be the perfect size for little hands and mouths! This teether is textured on both sides to provide maximum relief for your little ones sore, teething gums. '),
(3, 'Organic Elephant Teether', 16.99, '3.jpg', 'Soothe and entertain your baby with this Organic Elephant Teether. The sweet, friendly elephant�is easy to grasp and snuggle and so is the perfect toy for your teething little one blessing!'),
(4, 'Elephant Silicone Teether', 10.99, '4.jpg', 'These large and adorable mammals are a definitely a favorite toy for your new baby! Our elephant teether is the perfect teether for your animal loving baby'),
(5, "Organic Natural Rubber Teether", 11.99, '5.jpg', 'Babies will go gaga for this elephant teether made from BPA-free natural rubber. The soft and flexible teether is easy to hold and fun to chew.'),
(6, "Natural Baby Teether", 9.99, '6.jpg', 'Natural blue elephant teether. This elephant has different surfaces for sensory play and has bother soft and natural rubber to satisfy all stages of sore gums'),
(7, "Little Peanut", 12.99, '7.jpg', 'Onesie printed using professional garment inks, permanently embedding the ink into the fabric for maximum durability. This process ensures the design will last through many washes foryour baby.'),
(8, "Hello Im New Here", 10.99, '8.jpg',  'Short-sleeve cotton onesie features a charming baby elephant and balloon design. Made from natural bamboo fibers that are gentle enough for your baby, strong enough to handle many washes. '),
(9, "BBs Elephant Suit", 10.99, '9.jpg',  'This one-piece outfit is made from soft certified organic cotton. Perfect for your little ones first photoshoot or play time'),
(10, 'Trunks of love', 11.00, '10.jpg', 'This all natural cotton Onesie is perfect for a baby shower and perfect .'),
(11, 'Mom and Baby', 13.00, '2.jpg', 'A baby is an undeniable blessing. Celebrate your little blessing�s first birthday by jazzing him/her up with our graceful 1st birthday collection. '),
(12, 'BBs First Elephant', 16.99, '11.jpg', 'Hand knit woven outfit perfect for your little ones first photoshoot. '),
(13, 'Educational Music Toy', 9.99, '13.jpg', 'Perfect light up baby toys newborns up to toddlers. The texture of the elephant toy piano is short velvet fabric, which does not irritate the skin of the baby, does not shed, and will not fade. '),
(14, "You Light Up My Life", 10.99, '14.jpg', 'This stuffed animal for baby and music toy plays 12 classic songs in additional to sounds of nature and funny sounds. This baby toy has sounds and lights up. Babies will enjoy the music, sounds of birds and other animals. '),
(15, "Elephant Einstien", 14.99, '15.jpg', 'Super comfortable, safe and durable. If you want your baby to be the next baby Einstein, this is a great soft educational baby toy that can protect and sooth your baby.'),
(16, "The Great Baby Gift", 12.99, '16.jpg', 'Need the perfect baby shower toy or 1 year old Christmas gift or birthday present? You found it. Such a fun, soft, stuffed animal. '),
(17, "BBs Snuggle Friend", 10.99, '17.jpg',  'Protective. Comforting. A friend indeed. One of the largest, strongest animals in the animal kingdom sizes down to be a soft, cuddly friend to your little child.'),
(18, "Pull Around Elephant Toy", 10.99, '18.jpg',  'Let your little one have a new long trunked friend to play with around the house. Durable, dish washer safe, made with non-toxic dyes. '),
(19, 'Elephant Security Blanket', 17.00, '19.jpg', 'Every parent knows the importance of keeping a baby happy, calm and secure. Luckily, our baby security blanket with animal head do all of that while adding a little extra fun.� '),
(20, 'Hooded Towel', 13.00, '20.jpg', 'Ideal for making bath time and beach time fun!'),
(21, 'Cartoon Elephant', 10.99, '21.jpg', 'This is a perfect gift for a baby shower, If you�re not sure what to get your best friend or loved one, clicking this product is something you won�t regret. '),
(22, 'Blue Elephant Towel', 10.99, '22.jpg', 'The Elegant Baby Blue Elephant Hooded Towels are sized for newborns and babies, ideally for ages through 2 years.'),
(23, 'Fleece Blanket', 20.99, '23.jpg', 'A super cute baby blanket with a watercolor elephant print. The blanket is a super soft fleece and measures 30 x 40 inches. Personalize it with your little ones name! This personalized blanket also makes an excellent gift.'),
(24, 'Lovable Bath Companion', 9.99, '24.jpg', 'Kids bath collection. Cute Elephant friends. Perfect for your little toddlers bath time. '),
(25, 'Watercolor Elephant', 15.99, '25.jpg', 'Watercolor Pink Elephants Baby Nursery Art Elephant Wall D�cor. Perfect decor for baby�s nursery.'),
(26, "Elephant Nursey Art", 14.99, '26.jpg',  'Sweet baby elephant sitting in pink flowers nursery print, printable wall art to display in a nursery. Comes in three sizes. Perfect addition to your little ones new room.'),
(27, "Family Elephant Wall Decor", 14.99, '27.jpg',  'This product comes with five sheets in one package. Inside the package are included 70 large stickers. Great variety and assorted designs satisfy your diverse needs. Perfect Elephant decorations to add a cute nursery atmosphere'),
(28, "Baby crib Mobile", 30.99, '28.jpg',  'Use the baby nest as a bassinet for a bed, baby lounger pillow, travel bed, newborn pillow, changing station.'),
(29, "Happiest Baby", 7.99, '29.jpg',  'Are you still searching for a baby shower gift for a baby girl or boy, that both parents and children will love? Then you are in a perfect place as this giant elephant pillow for babies might be exactly what you are looking for.'),
(30, "Dream Big", 8.99, '30.jpg',  'Elephant sticker, perfect for your babys nursey');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `UID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(150) NOT NULL DEFAULT '',
  `CONTACT` varchar(150) NOT NULL DEFAULT '',
  `ADDRESS` text,
  `CITY` varchar(45) NOT NULL DEFAULT '',
  `ZIPCODE` varchar(9) NOT NULL DEFAULT '',
  `EMAIL` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--

CREATE TABLE `administrators` (
  `adminID` int(11) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`adminID`, `emailAddress`, `password`) VALUES
(1, 'admin@elephant4bbs1.com', '$2a$10$PEnmRwrKKlFKJwop/IzsVeGARZvQhJp0jl.SRGkdrYVHcLn1GbVqq');

-- --------------------------------------------------------

-- Create a user named elephant_bbs
GRANT SELECT, INSERT, UPDATE, DELETE
ON *
TO elephant_bbs@localhost
IDENTIFIED BY 'elephant';