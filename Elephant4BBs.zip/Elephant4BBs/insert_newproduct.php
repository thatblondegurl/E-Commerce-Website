<html>
<head>
  <title>Elephant4BBs Entry Results</title>
</head>
<body>
<h1>Book-Elephant4BBs Entry Results</h1>
<?php
  // create short variable names
  $productid=$_POST['productid'];
  $productname=$_POST['productname'];
  $description=$_POST['description'];
  $price=$_POST['price'];

  if (!$productid || !$productname || !$description || !$price) {
     echo "You have not entered all the required details.<br />"
          ."Please go back and try again.";
     exit;
  }

  if (!get_magic_quotes_gpc()) {
    $productid = addslashes($productid);
    $productname = addslashes($productname);
    $description = addslashes($description);
    $price = doubleval($price);
  }

  @ $db = new mysqli('localhost', 'elephant_bbs', 'elephant', 'elephants4bbs1');

  if (mysqli_connect_errno()) {
     echo "Error: Could not connect to database.  Please try again later.";
     exit;
  }

  $query = "insert into searches values
            ('".$productid."', '".$productname."', '".$description."', '".$price."')";
  $result = $db->query($query);

  if ($result) {
      echo  $db->affected_rows." product inserted into database.";
  } else {
  	  echo "An error has occurred.  The item was not added.";
  }

  $db->close();
?>
</body>
</html>
