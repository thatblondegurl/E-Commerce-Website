<?php 
	$con=mysqli_connect("localhost","elephant_bbs","elephant","elephants4bbs1");
	if(!$con){
		die("Database Connection Failed");
	}
?>